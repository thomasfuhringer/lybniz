/****************************************************************
 *   Function graph plotter                                     *
 *   2012 by Thomas F�hringer <thomasfuhringer@gmail.com>       *
 *   Provided under the terms of the GPL.                       *
 ****************************************************************/

#include <QtGui/QApplication>
#include "MainWindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.setApplicationName("Lybniz");
    app.setWindowIcon(QIcon(":/Images/App.svg"));
    MainWindow mainWindow;
    mainWindow.show();

    return app.exec();
}
